package com.sportsante.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
