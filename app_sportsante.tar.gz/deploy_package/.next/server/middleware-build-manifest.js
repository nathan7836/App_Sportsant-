globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/de0b69ea5875b0af.js",
    "static/chunks/3f0d2f5584d1478f.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/3a94daa1c77c8122.js",
    "static/chunks/0ffc5bac5e2cf033.js",
    "static/chunks/turbopack-10d04fcd3868b845.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];