module.exports=[54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},29173,(a,b,c)=>{b.exports=a.x("@prisma/client",()=>require("@prisma/client"))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__2fd7f811._.js.map