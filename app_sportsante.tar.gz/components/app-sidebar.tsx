
"use client"

import Link from "next/link"
import { Calendar, CreditCard, Home, Settings, Users, User, Euro, Dumbbell, Lock, CalendarClock } from "lucide-react"

import {
    Sidebar,
    SidebarContent,
    SidebarGroup,
    SidebarGroupContent,
    SidebarGroupLabel,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
    SidebarHeader,
    SidebarRail,
    SidebarFooter,
} from "@/components/ui/sidebar"
import { useSidebar } from "@/components/ui/sidebar"

// Menu items.
const items = [
    {
        title: "Tableau de bord",
        url: "/",
        icon: Home,
    },
    {
        title: "Clients",
        url: "/clients",
        icon: User,
    },
    {
        title: "Planning",
        url: "/planning",
        icon: Calendar,
    },
    {
        title: "Coachs",
        url: "/coaches",
        icon: Users,
    },
    {
        title: "Services",
        url: "/services",
        icon: Dumbbell,
    },
    {
        title: "Facturation",
        url: "/billing",
        icon: Euro,
    },
]

export function AppSidebar({ userRole, ...props }: React.ComponentProps<typeof Sidebar> & { userRole?: string }) {
    const { setOpenMobile, isMobile } = useSidebar()

    // Handle navigation with auto-close on mobile
    const handleNavClick = () => {
        if (isMobile) {
            setOpenMobile(false)
        }
    }

    // Common button classes optimized for touch
    const menuButtonClasses = `
        hover:bg-primary/10 hover:text-primary
        active:bg-primary/20 active:scale-[0.98]
        transition-all duration-200
        min-h-[44px] touch-manipulation select-none
    `

    return (
        <Sidebar collapsible="icon" {...props}>
            <SidebarHeader
                className="p-4 border-b"
                style={{
                    paddingTop: "calc(1rem + env(safe-area-inset-top, 0px))",
                }}
            >
                <h2 className="text-xl font-bold text-primary tracking-tight">SportSanté</h2>
            </SidebarHeader>
            <SidebarContent className="py-2">
                <SidebarGroup>
                    <SidebarGroupLabel className="px-4 text-xs uppercase tracking-wider text-muted-foreground/70">
                        Menu Principal
                    </SidebarGroupLabel>
                    <SidebarGroupContent className="px-2">
                        <SidebarMenu className="space-y-1">
                            {items.filter(item => {
                                if (userRole === "COACH") {
                                    return item.title === "Planning"
                                }
                                return true
                            }).map((item) => (
                                <SidebarMenuItem key={item.title}>
                                    <SidebarMenuButton
                                        asChild
                                        tooltip={item.title}
                                        className={menuButtonClasses}
                                    >
                                        <Link
                                            href={item.url}
                                            onClick={handleNavClick}
                                            style={{ WebkitTapHighlightColor: 'transparent' }}
                                        >
                                            <item.icon className="h-5 w-5 shrink-0" />
                                            <span className="font-medium">{item.title}</span>
                                        </Link>
                                    </SidebarMenuButton>
                                </SidebarMenuItem>
                            ))}

                            {userRole === "ADMIN" && (
                                <>
                                    <SidebarMenuItem key="Admin Users">
                                        <SidebarMenuButton
                                            asChild
                                            tooltip="Gestion Utilisateurs"
                                            className={menuButtonClasses}
                                        >
                                            <Link
                                                href="/admin/users"
                                                onClick={handleNavClick}
                                                style={{ WebkitTapHighlightColor: 'transparent' }}
                                            >
                                                <Lock className="h-5 w-5 shrink-0" />
                                                <span className="font-medium">Gestion Utilisateurs</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                    <SidebarMenuItem key="Admin Requests">
                                        <SidebarMenuButton
                                            asChild
                                            tooltip="Demandes"
                                            className={menuButtonClasses}
                                        >
                                            <Link
                                                href="/admin/requests"
                                                onClick={handleNavClick}
                                                style={{ WebkitTapHighlightColor: 'transparent' }}
                                            >
                                                <CalendarClock className="h-5 w-5 shrink-0" />
                                                <span className="font-medium">Demandes</span>
                                            </Link>
                                        </SidebarMenuButton>
                                    </SidebarMenuItem>
                                </>
                            )}
                        </SidebarMenu>
                    </SidebarGroupContent>
                </SidebarGroup>
            </SidebarContent>
            <SidebarFooter
                className="p-4 border-t"
                style={{
                    paddingBottom: "calc(1rem + env(safe-area-inset-bottom, 0px))",
                }}
            >
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton
                            asChild
                            tooltip="Paramètres"
                            className={menuButtonClasses}
                        >
                            <Link
                                href="/settings"
                                onClick={handleNavClick}
                                style={{ WebkitTapHighlightColor: 'transparent' }}
                            >
                                <Settings className="h-5 w-5 shrink-0" />
                                <span className="font-medium">Paramètres</span>
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarFooter>
            <SidebarRail />
        </Sidebar>
    )
}
